def success4x9(s):
    deck = s[:]
    table = deck[:-4]
    hand = deck[-4:]

    for card in hand:
        j = card
        while True:
            if j % 10 == 0:
                break  # King, stop here
            suit = (j - 1) // 10
            pos_in_suit = (j - 1) % 10
            if suit == 0:
                pos = pos_in_suit
            elif suit == 1:
                pos = 9 + pos_in_suit
            elif suit == 2:
                pos = 18 + pos_in_suit
            else:  # suit 3
                pos = 27 + pos_in_suit
            if pos >= 36:
                break  # Invalid position, should not happen with correct input
            # Swap j with table[pos]
            old_j = table[pos]
            table[pos] = j
            j = old_j
            if j % 10 == 0:
                break

    # Check if each row is sorted in ascending order
    for row in range(4):
        start = row * 9
        end = start + 9
        row_slice = table[start:end]
        if row_slice != sorted(row_slice):
            return False
    return True