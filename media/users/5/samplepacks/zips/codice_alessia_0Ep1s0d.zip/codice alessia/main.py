j = 19
# print(j//10)

if j//10 == 0:
    pos = j - 1
elif j//10 == 1:
    pos = j - 2
elif j//10 == 2:
    pos = j - 3
else:
    pos = j - 4

print(pos)